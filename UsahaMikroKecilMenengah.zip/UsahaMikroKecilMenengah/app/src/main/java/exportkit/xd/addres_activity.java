
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class addres_activity extends Activity {

	
	private View _bg__addres_ek2;
	private TextView priscekila;
	private TextView _3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states;
	private TextView __99_1234567890;
	private TextView edit;
	private ImageView vector_ek77;
	private ImageView vector_ek78;
	private ImageView vector_ek79;
	private View ellipse_123;
	private ImageView vector_41;
	private TextView priscekila_ek1;
	private TextView _3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states_ek1;
	private TextView __99_1234567890_ek1;
	private TextView edit_ek1;
	private ImageView vector_ek80;
	private ImageView vector_ek81;
	private ImageView vector_ek82;
	private TextView next;
	private View rectangle_406_ek5;
	private TextView ship_to;
	private View line_39_ek6;
	private ImageView vector_ek83;
	private ImageView vector_ek84;
	private ImageView vector_ek85;
	private ImageView vector_ek86;
	private ImageView rectangle_ek86;
	private ImageView combined_shape_ek12;
	private ImageView rectangle_ek87;
	private ImageView wifi_ek12;
	private ImageView mobile_signal_ek12;
	private TextView _9_41_ek12;
	private View home_indicator_ek14;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.addres);

		
		_bg__addres_ek2 = (View) findViewById(R.id._bg__addres_ek2);
		priscekila = (TextView) findViewById(R.id.priscekila);
		_3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states = (TextView) findViewById(R.id._3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states);
		__99_1234567890 = (TextView) findViewById(R.id.__99_1234567890);
		edit = (TextView) findViewById(R.id.edit);
		vector_ek77 = (ImageView) findViewById(R.id.vector_ek77);
		vector_ek78 = (ImageView) findViewById(R.id.vector_ek78);
		vector_ek79 = (ImageView) findViewById(R.id.vector_ek79);
		ellipse_123 = (View) findViewById(R.id.ellipse_123);
		vector_41 = (ImageView) findViewById(R.id.vector_41);
		priscekila_ek1 = (TextView) findViewById(R.id.priscekila_ek1);
		_3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states_ek1 = (TextView) findViewById(R.id._3711_spring_hill_rd_undefined_tallahassee__nevada_52874_united_states_ek1);
		__99_1234567890_ek1 = (TextView) findViewById(R.id.__99_1234567890_ek1);
		edit_ek1 = (TextView) findViewById(R.id.edit_ek1);
		vector_ek80 = (ImageView) findViewById(R.id.vector_ek80);
		vector_ek81 = (ImageView) findViewById(R.id.vector_ek81);
		vector_ek82 = (ImageView) findViewById(R.id.vector_ek82);
		next = (TextView) findViewById(R.id.next);
		rectangle_406_ek5 = (View) findViewById(R.id.rectangle_406_ek5);
		ship_to = (TextView) findViewById(R.id.ship_to);
		line_39_ek6 = (View) findViewById(R.id.line_39_ek6);
		vector_ek83 = (ImageView) findViewById(R.id.vector_ek83);
		vector_ek84 = (ImageView) findViewById(R.id.vector_ek84);
		vector_ek85 = (ImageView) findViewById(R.id.vector_ek85);
		vector_ek86 = (ImageView) findViewById(R.id.vector_ek86);
		rectangle_ek86 = (ImageView) findViewById(R.id.rectangle_ek86);
		combined_shape_ek12 = (ImageView) findViewById(R.id.combined_shape_ek12);
		rectangle_ek87 = (ImageView) findViewById(R.id.rectangle_ek87);
		wifi_ek12 = (ImageView) findViewById(R.id.wifi_ek12);
		mobile_signal_ek12 = (ImageView) findViewById(R.id.mobile_signal_ek12);
		_9_41_ek12 = (TextView) findViewById(R.id._9_41_ek12);
		home_indicator_ek14 = (View) findViewById(R.id.home_indicator_ek14);
	
		
		//custom code goes here
	
	}
}
	
	