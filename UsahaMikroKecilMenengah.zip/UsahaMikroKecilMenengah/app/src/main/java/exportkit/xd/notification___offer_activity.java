
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class notification___offer_activity extends Activity {

	
	private View _bg__notification___offer_ek2;
	private ImageView vector_ek20;
	private ImageView vector_ek21;
	private TextView the_best_title;
	private TextView culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo;
	private TextView april_30__2014_1_01_pm;
	private ImageView vector_ek22;
	private ImageView vector_ek23;
	private TextView summer_offer_98__cashback;
	private TextView culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor;
	private TextView april_30__2014_1_01_pm_ek1;
	private ImageView vector_ek24;
	private ImageView vector_ek25;
	private TextView special_offer_25__off;
	private TextView culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek1;
	private TextView april_30__2014_1_01_pm_ek2;
	private TextView payment_ek2;
	private View rectangle_406_ek2;
	private TextView payment_ek3;
	private View line_39_ek2;
	private ImageView vector_ek26;
	private ImageView vector_ek27;
	private ImageView vector_ek28;
	private ImageView vector_ek29;
	private ImageView rectangle_ek6;
	private ImageView combined_shape_ek3;
	private ImageView rectangle_ek7;
	private ImageView wifi_ek3;
	private ImageView mobile_signal_ek3;
	private TextView _9_41_ek3;
	private View home_indicator_ek3;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.notification___offer);

		
		_bg__notification___offer_ek2 = (View) findViewById(R.id._bg__notification___offer_ek2);
		vector_ek20 = (ImageView) findViewById(R.id.vector_ek20);
		vector_ek21 = (ImageView) findViewById(R.id.vector_ek21);
		the_best_title = (TextView) findViewById(R.id.the_best_title);
		culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo = (TextView) findViewById(R.id.culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo);
		april_30__2014_1_01_pm = (TextView) findViewById(R.id.april_30__2014_1_01_pm);
		vector_ek22 = (ImageView) findViewById(R.id.vector_ek22);
		vector_ek23 = (ImageView) findViewById(R.id.vector_ek23);
		summer_offer_98__cashback = (TextView) findViewById(R.id.summer_offer_98__cashback);
		culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor = (TextView) findViewById(R.id.culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor);
		april_30__2014_1_01_pm_ek1 = (TextView) findViewById(R.id.april_30__2014_1_01_pm_ek1);
		vector_ek24 = (ImageView) findViewById(R.id.vector_ek24);
		vector_ek25 = (ImageView) findViewById(R.id.vector_ek25);
		special_offer_25__off = (TextView) findViewById(R.id.special_offer_25__off);
		culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek1 = (TextView) findViewById(R.id.culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek1);
		april_30__2014_1_01_pm_ek2 = (TextView) findViewById(R.id.april_30__2014_1_01_pm_ek2);
		payment_ek2 = (TextView) findViewById(R.id.payment_ek2);
		rectangle_406_ek2 = (View) findViewById(R.id.rectangle_406_ek2);
		payment_ek3 = (TextView) findViewById(R.id.payment_ek3);
		line_39_ek2 = (View) findViewById(R.id.line_39_ek2);
		vector_ek26 = (ImageView) findViewById(R.id.vector_ek26);
		vector_ek27 = (ImageView) findViewById(R.id.vector_ek27);
		vector_ek28 = (ImageView) findViewById(R.id.vector_ek28);
		vector_ek29 = (ImageView) findViewById(R.id.vector_ek29);
		rectangle_ek6 = (ImageView) findViewById(R.id.rectangle_ek6);
		combined_shape_ek3 = (ImageView) findViewById(R.id.combined_shape_ek3);
		rectangle_ek7 = (ImageView) findViewById(R.id.rectangle_ek7);
		wifi_ek3 = (ImageView) findViewById(R.id.wifi_ek3);
		mobile_signal_ek3 = (ImageView) findViewById(R.id.mobile_signal_ek3);
		_9_41_ek3 = (TextView) findViewById(R.id._9_41_ek3);
		home_indicator_ek3 = (View) findViewById(R.id.home_indicator_ek3);
	
		
		//custom code goes here
	
	}
}
	
	