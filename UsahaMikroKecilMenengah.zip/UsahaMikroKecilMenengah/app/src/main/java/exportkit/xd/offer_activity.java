
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class offer_activity extends Activity {

	
	private View _bg__offer_ek5;
	private ImageView image_52;
	private ImageView image_54;
	private ImageView image_53;
	private TextView title_ek1;
	private View rectangle_402_ek1;
	private TextView _08_ek1;
	private TextView ___ek2;
	private TextView ___ek3;
	private View rectangle_403_ek1;
	private TextView _34_ek1;
	private View rectangle_404_ek2;
	private TextView _52_ek1;
	private TextView title_ek2;
	private View rectangle_402_ek2;
	private TextView _08_ek2;
	private TextView ___ek4;
	private TextView ___ek5;
	private View rectangle_403_ek2;
	private TextView _34_ek2;
	private View rectangle_404_ek3;
	private TextView _52_ek2;
	private TextView title_ek3;
	private View rectangle_402_ek3;
	private TextView _08_ek3;
	private TextView ___ek6;
	private TextView ___ek7;
	private View rectangle_403_ek3;
	private TextView _34_ek3;
	private View rectangle_404_ek4;
	private TextView _52_ek3;
	private View rectangle_406_ek8;
	private TextView ship_to_ek1;
	private View line_39_ek9;
	private ImageView vector_ek107;
	private ImageView vector_ek108;
	private ImageView vector_ek109;
	private ImageView vector_ek110;
	private ImageView rectangle_ek97;
	private ImageView combined_shape_ek16;
	private ImageView rectangle_ek98;
	private ImageView wifi_ek16;
	private ImageView mobile_signal_ek16;
	private TextView _9_41_ek16;
	private View home_indicator_ek18;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.offer);

		
		_bg__offer_ek5 = (View) findViewById(R.id._bg__offer_ek5);
		image_52 = (ImageView) findViewById(R.id.image_52);
		image_54 = (ImageView) findViewById(R.id.image_54);
		image_53 = (ImageView) findViewById(R.id.image_53);
		title_ek1 = (TextView) findViewById(R.id.title_ek1);
		rectangle_402_ek1 = (View) findViewById(R.id.rectangle_402_ek1);
		_08_ek1 = (TextView) findViewById(R.id._08_ek1);
		___ek2 = (TextView) findViewById(R.id.___ek2);
		___ek3 = (TextView) findViewById(R.id.___ek3);
		rectangle_403_ek1 = (View) findViewById(R.id.rectangle_403_ek1);
		_34_ek1 = (TextView) findViewById(R.id._34_ek1);
		rectangle_404_ek2 = (View) findViewById(R.id.rectangle_404_ek2);
		_52_ek1 = (TextView) findViewById(R.id._52_ek1);
		title_ek2 = (TextView) findViewById(R.id.title_ek2);
		rectangle_402_ek2 = (View) findViewById(R.id.rectangle_402_ek2);
		_08_ek2 = (TextView) findViewById(R.id._08_ek2);
		___ek4 = (TextView) findViewById(R.id.___ek4);
		___ek5 = (TextView) findViewById(R.id.___ek5);
		rectangle_403_ek2 = (View) findViewById(R.id.rectangle_403_ek2);
		_34_ek2 = (TextView) findViewById(R.id._34_ek2);
		rectangle_404_ek3 = (View) findViewById(R.id.rectangle_404_ek3);
		_52_ek2 = (TextView) findViewById(R.id._52_ek2);
		title_ek3 = (TextView) findViewById(R.id.title_ek3);
		rectangle_402_ek3 = (View) findViewById(R.id.rectangle_402_ek3);
		_08_ek3 = (TextView) findViewById(R.id._08_ek3);
		___ek6 = (TextView) findViewById(R.id.___ek6);
		___ek7 = (TextView) findViewById(R.id.___ek7);
		rectangle_403_ek3 = (View) findViewById(R.id.rectangle_403_ek3);
		_34_ek3 = (TextView) findViewById(R.id._34_ek3);
		rectangle_404_ek4 = (View) findViewById(R.id.rectangle_404_ek4);
		_52_ek3 = (TextView) findViewById(R.id._52_ek3);
		rectangle_406_ek8 = (View) findViewById(R.id.rectangle_406_ek8);
		ship_to_ek1 = (TextView) findViewById(R.id.ship_to_ek1);
		line_39_ek9 = (View) findViewById(R.id.line_39_ek9);
		vector_ek107 = (ImageView) findViewById(R.id.vector_ek107);
		vector_ek108 = (ImageView) findViewById(R.id.vector_ek108);
		vector_ek109 = (ImageView) findViewById(R.id.vector_ek109);
		vector_ek110 = (ImageView) findViewById(R.id.vector_ek110);
		rectangle_ek97 = (ImageView) findViewById(R.id.rectangle_ek97);
		combined_shape_ek16 = (ImageView) findViewById(R.id.combined_shape_ek16);
		rectangle_ek98 = (ImageView) findViewById(R.id.rectangle_ek98);
		wifi_ek16 = (ImageView) findViewById(R.id.wifi_ek16);
		mobile_signal_ek16 = (ImageView) findViewById(R.id.mobile_signal_ek16);
		_9_41_ek16 = (TextView) findViewById(R.id._9_41_ek16);
		home_indicator_ek18 = (View) findViewById(R.id.home_indicator_ek18);
	
		
		//custom code goes here
	
	}
}
	
	