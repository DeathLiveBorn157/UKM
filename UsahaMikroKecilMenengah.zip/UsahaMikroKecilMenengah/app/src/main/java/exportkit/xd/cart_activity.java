
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class cart_activity extends Activity {

	
	private View _bg__cart_ek2;
	private View line_40;
	private View rectangle_397;
	private View rectangle_392_ek2;
	private ImageView vector_ek57;
	private ImageView vector_ek58;
	private ImageView vector_ek59;
	private TextView home_ek1;
	private View rectangle_394;
	private ImageView vector_ek60;
	private ImageView vector_ek61;
	private ImageView vector_ek62;
	private TextView cart_ek4;
	private View ellipse_ek2;
	private TextView _2_ek1;
	private View rectangle_396;
	private ImageView vector__stroke__ek49;
	private ImageView vector__stroke__ek50;
	private TextView account;
	private View rectangle_406_ek4;
	private TextView your_cart;
	private View line_39_ek4;
	private ImageView rectangle_ek84;
	private ImageView combined_shape_ek11;
	private ImageView rectangle_ek85;
	private ImageView wifi_ek11;
	private ImageView mobile_signal_ek11;
	private TextView _9_41_ek11;
	private View rectangle_433;
	private TextView outer_wanita;
	private TextView rp_59_000;
	private View image_47;
	private ImageView rectangle_430;
	private View rectangle_431;
	private ImageView rectangle_432;
	private TextView _1;
	private ImageView vector_ek63;
	private ImageView vector_ek64;
	private ImageView vector_ek65;
	private ImageView vector_ek66;
	private ImageView vector_ek67;
	private ImageView vector_ek68;
	private ImageView vector_ek69;
	private ImageView image_product_ek4;
	private TextView check_out;
	private TextView __598_86;
	private TextView items__3_;
	private TextView __40_00;
	private TextView shipping;
	private TextView __128_00;
	private TextView import_charges;
	private View line_39_ek5;
	private TextView __766_86;
	private TextView total_price_ek1;
	private View rectangle_433_ek1;
	private TextView kaos_lengan_pendek;
	private TextView rp_65_000;
	private View image_47_ek1;
	private View image_48;
	private ImageView rectangle_430_ek1;
	private View rectangle_431_ek1;
	private ImageView rectangle_432_ek1;
	private TextView _1_ek1;
	private ImageView vector_ek70;
	private ImageView vector_ek71;
	private ImageView vector_ek72;
	private ImageView vector_ek73;
	private ImageView vector_ek74;
	private ImageView vector_ek75;
	private ImageView vector_ek76;
	private ImageView image_product_ek5;
	private View home_indicator_ek13;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.cart);

		
		_bg__cart_ek2 = (View) findViewById(R.id._bg__cart_ek2);
		line_40 = (View) findViewById(R.id.line_40);
		rectangle_397 = (View) findViewById(R.id.rectangle_397);
		rectangle_392_ek2 = (View) findViewById(R.id.rectangle_392_ek2);
		vector_ek57 = (ImageView) findViewById(R.id.vector_ek57);
		vector_ek58 = (ImageView) findViewById(R.id.vector_ek58);
		vector_ek59 = (ImageView) findViewById(R.id.vector_ek59);
		home_ek1 = (TextView) findViewById(R.id.home_ek1);
		rectangle_394 = (View) findViewById(R.id.rectangle_394);
		vector_ek60 = (ImageView) findViewById(R.id.vector_ek60);
		vector_ek61 = (ImageView) findViewById(R.id.vector_ek61);
		vector_ek62 = (ImageView) findViewById(R.id.vector_ek62);
		cart_ek4 = (TextView) findViewById(R.id.cart_ek4);
		ellipse_ek2 = (View) findViewById(R.id.ellipse_ek2);
		_2_ek1 = (TextView) findViewById(R.id._2_ek1);
		rectangle_396 = (View) findViewById(R.id.rectangle_396);
		vector__stroke__ek49 = (ImageView) findViewById(R.id.vector__stroke__ek49);
		vector__stroke__ek50 = (ImageView) findViewById(R.id.vector__stroke__ek50);
		account = (TextView) findViewById(R.id.account);
		rectangle_406_ek4 = (View) findViewById(R.id.rectangle_406_ek4);
		your_cart = (TextView) findViewById(R.id.your_cart);
		line_39_ek4 = (View) findViewById(R.id.line_39_ek4);
		rectangle_ek84 = (ImageView) findViewById(R.id.rectangle_ek84);
		combined_shape_ek11 = (ImageView) findViewById(R.id.combined_shape_ek11);
		rectangle_ek85 = (ImageView) findViewById(R.id.rectangle_ek85);
		wifi_ek11 = (ImageView) findViewById(R.id.wifi_ek11);
		mobile_signal_ek11 = (ImageView) findViewById(R.id.mobile_signal_ek11);
		_9_41_ek11 = (TextView) findViewById(R.id._9_41_ek11);
		rectangle_433 = (View) findViewById(R.id.rectangle_433);
		outer_wanita = (TextView) findViewById(R.id.outer_wanita);
		rp_59_000 = (TextView) findViewById(R.id.rp_59_000);
		image_47 = (View) findViewById(R.id.image_47);
		rectangle_430 = (ImageView) findViewById(R.id.rectangle_430);
		rectangle_431 = (View) findViewById(R.id.rectangle_431);
		rectangle_432 = (ImageView) findViewById(R.id.rectangle_432);
		_1 = (TextView) findViewById(R.id._1);
		vector_ek63 = (ImageView) findViewById(R.id.vector_ek63);
		vector_ek64 = (ImageView) findViewById(R.id.vector_ek64);
		vector_ek65 = (ImageView) findViewById(R.id.vector_ek65);
		vector_ek66 = (ImageView) findViewById(R.id.vector_ek66);
		vector_ek67 = (ImageView) findViewById(R.id.vector_ek67);
		vector_ek68 = (ImageView) findViewById(R.id.vector_ek68);
		vector_ek69 = (ImageView) findViewById(R.id.vector_ek69);
		image_product_ek4 = (ImageView) findViewById(R.id.image_product_ek4);
		check_out = (TextView) findViewById(R.id.check_out);
		__598_86 = (TextView) findViewById(R.id.__598_86);
		items__3_ = (TextView) findViewById(R.id.items__3_);
		__40_00 = (TextView) findViewById(R.id.__40_00);
		shipping = (TextView) findViewById(R.id.shipping);
		__128_00 = (TextView) findViewById(R.id.__128_00);
		import_charges = (TextView) findViewById(R.id.import_charges);
		line_39_ek5 = (View) findViewById(R.id.line_39_ek5);
		__766_86 = (TextView) findViewById(R.id.__766_86);
		total_price_ek1 = (TextView) findViewById(R.id.total_price_ek1);
		rectangle_433_ek1 = (View) findViewById(R.id.rectangle_433_ek1);
		kaos_lengan_pendek = (TextView) findViewById(R.id.kaos_lengan_pendek);
		rp_65_000 = (TextView) findViewById(R.id.rp_65_000);
		image_47_ek1 = (View) findViewById(R.id.image_47_ek1);
		image_48 = (View) findViewById(R.id.image_48);
		rectangle_430_ek1 = (ImageView) findViewById(R.id.rectangle_430_ek1);
		rectangle_431_ek1 = (View) findViewById(R.id.rectangle_431_ek1);
		rectangle_432_ek1 = (ImageView) findViewById(R.id.rectangle_432_ek1);
		_1_ek1 = (TextView) findViewById(R.id._1_ek1);
		vector_ek70 = (ImageView) findViewById(R.id.vector_ek70);
		vector_ek71 = (ImageView) findViewById(R.id.vector_ek71);
		vector_ek72 = (ImageView) findViewById(R.id.vector_ek72);
		vector_ek73 = (ImageView) findViewById(R.id.vector_ek73);
		vector_ek74 = (ImageView) findViewById(R.id.vector_ek74);
		vector_ek75 = (ImageView) findViewById(R.id.vector_ek75);
		vector_ek76 = (ImageView) findViewById(R.id.vector_ek76);
		image_product_ek5 = (ImageView) findViewById(R.id.image_product_ek5);
		home_indicator_ek13 = (View) findViewById(R.id.home_indicator_ek13);
	
		
		//custom code goes here
	
	}
}
	
	