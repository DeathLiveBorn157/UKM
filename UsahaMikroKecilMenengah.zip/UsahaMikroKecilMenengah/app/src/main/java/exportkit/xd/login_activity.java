
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

public class login_activity extends Activity {

	
	private View _bg__login_ek2;
	private ImageView image_1_ek1;
	private ImageView vector__stroke__ek4;
	private ImageView vector__stroke__ek5;
	private TextView your_email;
	private ImageView vector__stroke__ek6;
	private ImageView vector__stroke__ek7;
	private ImageView vector__stroke__ek8;
	private TextView password;
	private TextView sign_in;
	private TextView or;
	private View line_37;
	private View line_38;
	private ImageView vector_ek42;
	private ImageView vector_ek43;
	private ImageView vector_ek44;
	private ImageView vector_ek45;
	private TextView login_with_google;
	private ImageView vector_ek46;
	private TextView login_with_facebook;
	private TextView forgot_password_;
	private TextView _don_t_have_a_account__register;
	private ImageView rectangle_ek10;
	private ImageView combined_shape_ek5;
	private ImageView rectangle_ek11;
	private ImageView wifi_ek5;
	private ImageView mobile_signal_ek5;
	private TextView _9_41_ek5;
	private View home_indicator_ek5;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		
		_bg__login_ek2 = (View) findViewById(R.id._bg__login_ek2);
		image_1_ek1 = (ImageView) findViewById(R.id.image_1_ek1);
		vector__stroke__ek4 = (ImageView) findViewById(R.id.vector__stroke__ek4);
		vector__stroke__ek5 = (ImageView) findViewById(R.id.vector__stroke__ek5);
		your_email = (TextView) findViewById(R.id.your_email);
		vector__stroke__ek6 = (ImageView) findViewById(R.id.vector__stroke__ek6);
		vector__stroke__ek7 = (ImageView) findViewById(R.id.vector__stroke__ek7);
		vector__stroke__ek8 = (ImageView) findViewById(R.id.vector__stroke__ek8);
		password = (TextView) findViewById(R.id.password);
		sign_in = (TextView) findViewById(R.id.sign_in);
		or = (TextView) findViewById(R.id.or);
		line_37 = (View) findViewById(R.id.line_37);
		line_38 = (View) findViewById(R.id.line_38);
		vector_ek42 = (ImageView) findViewById(R.id.vector_ek42);
		vector_ek43 = (ImageView) findViewById(R.id.vector_ek43);
		vector_ek44 = (ImageView) findViewById(R.id.vector_ek44);
		vector_ek45 = (ImageView) findViewById(R.id.vector_ek45);
		login_with_google = (TextView) findViewById(R.id.login_with_google);
		vector_ek46 = (ImageView) findViewById(R.id.vector_ek46);
		login_with_facebook = (TextView) findViewById(R.id.login_with_facebook);
		forgot_password_ = (TextView) findViewById(R.id.forgot_password_);
		_don_t_have_a_account__register = (TextView) findViewById(R.id._don_t_have_a_account__register);
		rectangle_ek10 = (ImageView) findViewById(R.id.rectangle_ek10);
		combined_shape_ek5 = (ImageView) findViewById(R.id.combined_shape_ek5);
		rectangle_ek11 = (ImageView) findViewById(R.id.rectangle_ek11);
		wifi_ek5 = (ImageView) findViewById(R.id.wifi_ek5);
		mobile_signal_ek5 = (ImageView) findViewById(R.id.mobile_signal_ek5);
		_9_41_ek5 = (TextView) findViewById(R.id._9_41_ek5);
		home_indicator_ek5 = (View) findViewById(R.id.home_indicator_ek5);
	
		
		_don_t_have_a_account__register.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), login2_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	