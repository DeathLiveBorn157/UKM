
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class bayar3_activity extends Activity {

	
	private View _bg__bayar3_ek2;
	private View rectangle_383;
	private ImageView vector_41_ek1;
	private TextView success;
	private TextView thank_you_for_shopping_using_owl_moon_market;
	private TextView back_to_order;
	private ImageView rectangle_ek95;
	private ImageView combined_shape_ek15;
	private ImageView rectangle_ek96;
	private ImageView wifi_ek15;
	private ImageView mobile_signal_ek15;
	private TextView _9_41_ek15;
	private View home_indicator_ek17;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.bayar3);

		
		_bg__bayar3_ek2 = (View) findViewById(R.id._bg__bayar3_ek2);
		rectangle_383 = (View) findViewById(R.id.rectangle_383);
		vector_41_ek1 = (ImageView) findViewById(R.id.vector_41_ek1);
		success = (TextView) findViewById(R.id.success);
		thank_you_for_shopping_using_owl_moon_market = (TextView) findViewById(R.id.thank_you_for_shopping_using_owl_moon_market);
		back_to_order = (TextView) findViewById(R.id.back_to_order);
		rectangle_ek95 = (ImageView) findViewById(R.id.rectangle_ek95);
		combined_shape_ek15 = (ImageView) findViewById(R.id.combined_shape_ek15);
		rectangle_ek96 = (ImageView) findViewById(R.id.rectangle_ek96);
		wifi_ek15 = (ImageView) findViewById(R.id.wifi_ek15);
		mobile_signal_ek15 = (ImageView) findViewById(R.id.mobile_signal_ek15);
		_9_41_ek15 = (TextView) findViewById(R.id._9_41_ek15);
		home_indicator_ek17 = (View) findViewById(R.id.home_indicator_ek17);
	
		
		//custom code goes here
	
	}
}
	
	