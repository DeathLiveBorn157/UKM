
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class menu_activity extends Activity {

	
	private View _bg__menu_ek2;
	private ImageView _8759b903_0b54_4853_a96d_ee3b1cfd4dd3_1;
	private View image_1;
	private View rectangle_13;
	private TextView search___;
	private ImageView vector__stroke_;
	private ImageView vector__stroke__ek1;
	private ImageView group_3;
	private ImageView fill_4;
	private ImageView vector;
	private ImageView we_fashion_store__1___1__1;
	private ImageView rectangle_1;
	private ImageView rectangle_5;
	private ImageView rectangle_6;
	private ImageView rectangle_7;
	private ImageView rectangle_2;
	private ImageView unsplash_sdeglmawch4;
	private ImageView rectangle_4;
	private View rectangle_8;
	private ImageView vector_ek1;
	private View ellipse_1;
	private TextView pakaian_wanita;
	private TextView sepatu;
	private TextView pakaian_pria;
	private TextView accessories_wanita;
	private TextView tas;
	private TextView accessories_pria;
	private TextView hijab;
	private TextView semua_kategori;
	private TextView produk_sesuai_kategori;
	private View ellipse_2;
	private TextView title;
	private View rectangle_402;
	private TextView _08;
	private TextView __;
	private TextView ___ek1;
	private View rectangle_403;
	private TextView _34;
	private TextView flash_sale_ek1;
	private ImageView unsplash_pvo1dnoj8ta;
	private TextView fs___nike_air_max_270_react___;
	private TextView __299_43;
	private TextView __534_33;
	private TextView _24__off;
	private ImageView unsplash_vlqzopdrsni;
	private TextView fs___quilted_maxi_cros___;
	private TextView __299_43_ek1;
	private TextView __534_33_ek1;
	private TextView _24__off_ek1;
	private ImageView unsplash_35hwxdrqbca;
	private TextView fs___nike_air_max_270_react____ek1;
	private TextView __299_43_ek2;
	private TextView __534_33_ek2;
	private TextView _24__off_ek2;
	private View rectangle_404_ek1;
	private TextView _30;
	private ImageView rectangle;
	private ImageView combined_shape;
	private ImageView rectangle_ek1;
	private ImageView wifi;
	private ImageView mobile_signal;
	private TextView _9_41;
	private View home_indicator;
	private ImageView tab_bar;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);

		
		_bg__menu_ek2 = (View) findViewById(R.id._bg__menu_ek2);
		_8759b903_0b54_4853_a96d_ee3b1cfd4dd3_1 = (ImageView) findViewById(R.id._8759b903_0b54_4853_a96d_ee3b1cfd4dd3_1);
		image_1 = (View) findViewById(R.id.image_1);
		rectangle_13 = (View) findViewById(R.id.rectangle_13);
		search___ = (TextView) findViewById(R.id.search___);
		vector__stroke_ = (ImageView) findViewById(R.id.vector__stroke_);
		vector__stroke__ek1 = (ImageView) findViewById(R.id.vector__stroke__ek1);
		group_3 = (ImageView) findViewById(R.id.group_3);
		fill_4 = (ImageView) findViewById(R.id.fill_4);
		vector = (ImageView) findViewById(R.id.vector);
		we_fashion_store__1___1__1 = (ImageView) findViewById(R.id.we_fashion_store__1___1__1);
		rectangle_1 = (ImageView) findViewById(R.id.rectangle_1);
		rectangle_5 = (ImageView) findViewById(R.id.rectangle_5);
		rectangle_6 = (ImageView) findViewById(R.id.rectangle_6);
		rectangle_7 = (ImageView) findViewById(R.id.rectangle_7);
		rectangle_2 = (ImageView) findViewById(R.id.rectangle_2);
		unsplash_sdeglmawch4 = (ImageView) findViewById(R.id.unsplash_sdeglmawch4);
		rectangle_4 = (ImageView) findViewById(R.id.rectangle_4);
		rectangle_8 = (View) findViewById(R.id.rectangle_8);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		ellipse_1 = (View) findViewById(R.id.ellipse_1);
		pakaian_wanita = (TextView) findViewById(R.id.pakaian_wanita);
		sepatu = (TextView) findViewById(R.id.sepatu);
		pakaian_pria = (TextView) findViewById(R.id.pakaian_pria);
		accessories_wanita = (TextView) findViewById(R.id.accessories_wanita);
		tas = (TextView) findViewById(R.id.tas);
		accessories_pria = (TextView) findViewById(R.id.accessories_pria);
		hijab = (TextView) findViewById(R.id.hijab);
		semua_kategori = (TextView) findViewById(R.id.semua_kategori);
		produk_sesuai_kategori = (TextView) findViewById(R.id.produk_sesuai_kategori);
		ellipse_2 = (View) findViewById(R.id.ellipse_2);
		title = (TextView) findViewById(R.id.title);
		rectangle_402 = (View) findViewById(R.id.rectangle_402);
		_08 = (TextView) findViewById(R.id._08);
		__ = (TextView) findViewById(R.id.__);
		___ek1 = (TextView) findViewById(R.id.___ek1);
		rectangle_403 = (View) findViewById(R.id.rectangle_403);
		_34 = (TextView) findViewById(R.id._34);
		flash_sale_ek1 = (TextView) findViewById(R.id.flash_sale_ek1);
		unsplash_pvo1dnoj8ta = (ImageView) findViewById(R.id.unsplash_pvo1dnoj8ta);
		fs___nike_air_max_270_react___ = (TextView) findViewById(R.id.fs___nike_air_max_270_react___);
		__299_43 = (TextView) findViewById(R.id.__299_43);
		__534_33 = (TextView) findViewById(R.id.__534_33);
		_24__off = (TextView) findViewById(R.id._24__off);
		unsplash_vlqzopdrsni = (ImageView) findViewById(R.id.unsplash_vlqzopdrsni);
		fs___quilted_maxi_cros___ = (TextView) findViewById(R.id.fs___quilted_maxi_cros___);
		__299_43_ek1 = (TextView) findViewById(R.id.__299_43_ek1);
		__534_33_ek1 = (TextView) findViewById(R.id.__534_33_ek1);
		_24__off_ek1 = (TextView) findViewById(R.id._24__off_ek1);
		unsplash_35hwxdrqbca = (ImageView) findViewById(R.id.unsplash_35hwxdrqbca);
		fs___nike_air_max_270_react____ek1 = (TextView) findViewById(R.id.fs___nike_air_max_270_react____ek1);
		__299_43_ek2 = (TextView) findViewById(R.id.__299_43_ek2);
		__534_33_ek2 = (TextView) findViewById(R.id.__534_33_ek2);
		_24__off_ek2 = (TextView) findViewById(R.id._24__off_ek2);
		rectangle_404_ek1 = (View) findViewById(R.id.rectangle_404_ek1);
		_30 = (TextView) findViewById(R.id._30);
		rectangle = (ImageView) findViewById(R.id.rectangle);
		combined_shape = (ImageView) findViewById(R.id.combined_shape);
		rectangle_ek1 = (ImageView) findViewById(R.id.rectangle_ek1);
		wifi = (ImageView) findViewById(R.id.wifi);
		mobile_signal = (ImageView) findViewById(R.id.mobile_signal);
		_9_41 = (TextView) findViewById(R.id._9_41);
		home_indicator = (View) findViewById(R.id.home_indicator);
		tab_bar = (ImageView) findViewById(R.id.tab_bar);
	
		
		//custom code goes here
	
	}
}
	
	