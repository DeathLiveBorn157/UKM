
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class notification_activity extends Activity {

	
	private View _bg__notification_ek3;
	private View rectangle_392;
	private TextView offer_ek1;
	private ImageView vector_ek14;
	private ImageView vector_ek15;
	private View ellipse;
	private TextView _3;
	private View rectangle_392_ek1;
	private TextView acivity;
	private ImageView vector__stroke__ek2;
	private ImageView vector__stroke__ek3;
	private View ellipse_ek1;
	private TextView _2;
	private View rectangle_406_ek1;
	private TextView payment_ek1;
	private View line_39_ek1;
	private ImageView vector_ek16;
	private ImageView vector_ek17;
	private ImageView vector_ek18;
	private ImageView vector_ek19;
	private ImageView rectangle_ek4;
	private ImageView combined_shape_ek2;
	private ImageView rectangle_ek5;
	private ImageView wifi_ek2;
	private ImageView mobile_signal_ek2;
	private TextView _9_41_ek2;
	private View home_indicator_ek2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.notification);

		
		_bg__notification_ek3 = (View) findViewById(R.id._bg__notification_ek3);
		rectangle_392 = (View) findViewById(R.id.rectangle_392);
		offer_ek1 = (TextView) findViewById(R.id.offer_ek1);
		vector_ek14 = (ImageView) findViewById(R.id.vector_ek14);
		vector_ek15 = (ImageView) findViewById(R.id.vector_ek15);
		ellipse = (View) findViewById(R.id.ellipse);
		_3 = (TextView) findViewById(R.id._3);
		rectangle_392_ek1 = (View) findViewById(R.id.rectangle_392_ek1);
		acivity = (TextView) findViewById(R.id.acivity);
		vector__stroke__ek2 = (ImageView) findViewById(R.id.vector__stroke__ek2);
		vector__stroke__ek3 = (ImageView) findViewById(R.id.vector__stroke__ek3);
		ellipse_ek1 = (View) findViewById(R.id.ellipse_ek1);
		_2 = (TextView) findViewById(R.id._2);
		rectangle_406_ek1 = (View) findViewById(R.id.rectangle_406_ek1);
		payment_ek1 = (TextView) findViewById(R.id.payment_ek1);
		line_39_ek1 = (View) findViewById(R.id.line_39_ek1);
		vector_ek16 = (ImageView) findViewById(R.id.vector_ek16);
		vector_ek17 = (ImageView) findViewById(R.id.vector_ek17);
		vector_ek18 = (ImageView) findViewById(R.id.vector_ek18);
		vector_ek19 = (ImageView) findViewById(R.id.vector_ek19);
		rectangle_ek4 = (ImageView) findViewById(R.id.rectangle_ek4);
		combined_shape_ek2 = (ImageView) findViewById(R.id.combined_shape_ek2);
		rectangle_ek5 = (ImageView) findViewById(R.id.rectangle_ek5);
		wifi_ek2 = (ImageView) findViewById(R.id.wifi_ek2);
		mobile_signal_ek2 = (ImageView) findViewById(R.id.mobile_signal_ek2);
		_9_41_ek2 = (TextView) findViewById(R.id._9_41_ek2);
		home_indicator_ek2 = (View) findViewById(R.id.home_indicator_ek2);
	
		
		//custom code goes here
	
	}
}
	
	