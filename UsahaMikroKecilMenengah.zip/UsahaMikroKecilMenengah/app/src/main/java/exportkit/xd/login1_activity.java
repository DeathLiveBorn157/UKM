
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class login1_activity extends Activity {

	
	private View __bg__login1_ek2;
	private ImageView image_1_ek2;
	private ImageView vector__stroke__ek9;
	private ImageView vector__stroke__ek10;
	private TextView your_email_ek1;
	private TextView sign_in_ek1;
	private TextView or_ek1;
	private View line_37_ek1;
	private View line_38_ek1;
	private ImageView vector_ek47;
	private ImageView vector_ek48;
	private ImageView vector_ek49;
	private ImageView vector_ek50;
	private TextView login_with_google_ek1;
	private ImageView vector_ek51;
	private TextView login_with_facebook_ek1;
	private TextView forgot_password__ek1;
	private TextView don_t_have_a_account__register_ek1;
	private ImageView vector__stroke__ek11;
	private ImageView vector__stroke__ek12;
	private ImageView vector__stroke__ek13;
	private TextView __________________;
	private View background_ek1;
	private View home_indicator_ek7;
	private ImageView dictation;
	private ImageView emoji;
	private ImageView rectangle_ek12;
	private TextView label;
	private ImageView rectangle_ek13;
	private TextView label_ek1;
	private ImageView rectangle_ek14;
	private TextView label_ek2;
	private ImageView rectangle_ek15;
	private TextView label_ek3;
	private ImageView delete_button;
	private View rectangle_ek16;
	private TextView symbol;
	private ImageView shift_ek1;
	private View rectangle_ek17;
	private TextView symbol_ek1;
	private View rectangle_ek18;
	private TextView symbol_ek2;
	private View rectangle_ek19;
	private TextView symbol_ek3;
	private View rectangle_ek20;
	private TextView symbol_ek4;
	private View rectangle_ek21;
	private TextView symbol_ek5;
	private View rectangle_ek22;
	private TextView symbol_ek6;
	private View rectangle_ek23;
	private TextView symbol_ek7;
	private View rectangle_ek24;
	private TextView symbol_ek8;
	private View rectangle_ek25;
	private TextView symbol_ek9;
	private View rectangle_ek26;
	private TextView symbol_ek10;
	private View rectangle_ek27;
	private TextView symbol_ek11;
	private View rectangle_ek28;
	private TextView symbol_ek12;
	private View rectangle_ek29;
	private TextView symbol_ek13;
	private View rectangle_ek30;
	private TextView symbol_ek14;
	private View rectangle_ek31;
	private TextView symbol_ek15;
	private View rectangle_ek32;
	private TextView symbol_ek16;
	private View rectangle_ek33;
	private TextView symbol_ek17;
	private View rectangle_ek34;
	private TextView symbol_ek18;
	private View rectangle_ek35;
	private TextView symbol_ek19;
	private View rectangle_ek36;
	private TextView symbol_ek20;
	private View rectangle_ek37;
	private TextView symbol_ek21;
	private View rectangle_ek38;
	private TextView symbol_ek22;
	private View rectangle_ek39;
	private TextView symbol_ek23;
	private View rectangle_ek40;
	private TextView symbol_ek24;
	private View rectangle_ek41;
	private TextView symbol_ek25;
	private View rectangle_ek42;
	private TextView symbol_ek26;
	private ImageView rectangle_ek43;
	private ImageView combined_shape_ek6;
	private ImageView rectangle_ek44;
	private ImageView wifi_ek6;
	private ImageView mobile_signal_ek6;
	private TextView _9_41_ek6;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login1);

		
		__bg__login1_ek2 = (View) findViewById(R.id.__bg__login1_ek2);
		image_1_ek2 = (ImageView) findViewById(R.id.image_1_ek2);
		vector__stroke__ek9 = (ImageView) findViewById(R.id.vector__stroke__ek9);
		vector__stroke__ek10 = (ImageView) findViewById(R.id.vector__stroke__ek10);
		your_email_ek1 = (TextView) findViewById(R.id.your_email_ek1);
		sign_in_ek1 = (TextView) findViewById(R.id.sign_in_ek1);
		or_ek1 = (TextView) findViewById(R.id.or_ek1);
		line_37_ek1 = (View) findViewById(R.id.line_37_ek1);
		line_38_ek1 = (View) findViewById(R.id.line_38_ek1);
		vector_ek47 = (ImageView) findViewById(R.id.vector_ek47);
		vector_ek48 = (ImageView) findViewById(R.id.vector_ek48);
		vector_ek49 = (ImageView) findViewById(R.id.vector_ek49);
		vector_ek50 = (ImageView) findViewById(R.id.vector_ek50);
		login_with_google_ek1 = (TextView) findViewById(R.id.login_with_google_ek1);
		vector_ek51 = (ImageView) findViewById(R.id.vector_ek51);
		login_with_facebook_ek1 = (TextView) findViewById(R.id.login_with_facebook_ek1);
		forgot_password__ek1 = (TextView) findViewById(R.id.forgot_password__ek1);
		don_t_have_a_account__register_ek1 = (TextView) findViewById(R.id.don_t_have_a_account__register_ek1);
		vector__stroke__ek11 = (ImageView) findViewById(R.id.vector__stroke__ek11);
		vector__stroke__ek12 = (ImageView) findViewById(R.id.vector__stroke__ek12);
		vector__stroke__ek13 = (ImageView) findViewById(R.id.vector__stroke__ek13);
		__________________ = (TextView) findViewById(R.id.__________________);
		background_ek1 = (View) findViewById(R.id.background_ek1);
		home_indicator_ek7 = (View) findViewById(R.id.home_indicator_ek7);
		dictation = (ImageView) findViewById(R.id.dictation);
		emoji = (ImageView) findViewById(R.id.emoji);
		rectangle_ek12 = (ImageView) findViewById(R.id.rectangle_ek12);
		label = (TextView) findViewById(R.id.label);
		rectangle_ek13 = (ImageView) findViewById(R.id.rectangle_ek13);
		label_ek1 = (TextView) findViewById(R.id.label_ek1);
		rectangle_ek14 = (ImageView) findViewById(R.id.rectangle_ek14);
		label_ek2 = (TextView) findViewById(R.id.label_ek2);
		rectangle_ek15 = (ImageView) findViewById(R.id.rectangle_ek15);
		label_ek3 = (TextView) findViewById(R.id.label_ek3);
		delete_button = (ImageView) findViewById(R.id.delete_button);
		rectangle_ek16 = (View) findViewById(R.id.rectangle_ek16);
		symbol = (TextView) findViewById(R.id.symbol);
		shift_ek1 = (ImageView) findViewById(R.id.shift_ek1);
		rectangle_ek17 = (View) findViewById(R.id.rectangle_ek17);
		symbol_ek1 = (TextView) findViewById(R.id.symbol_ek1);
		rectangle_ek18 = (View) findViewById(R.id.rectangle_ek18);
		symbol_ek2 = (TextView) findViewById(R.id.symbol_ek2);
		rectangle_ek19 = (View) findViewById(R.id.rectangle_ek19);
		symbol_ek3 = (TextView) findViewById(R.id.symbol_ek3);
		rectangle_ek20 = (View) findViewById(R.id.rectangle_ek20);
		symbol_ek4 = (TextView) findViewById(R.id.symbol_ek4);
		rectangle_ek21 = (View) findViewById(R.id.rectangle_ek21);
		symbol_ek5 = (TextView) findViewById(R.id.symbol_ek5);
		rectangle_ek22 = (View) findViewById(R.id.rectangle_ek22);
		symbol_ek6 = (TextView) findViewById(R.id.symbol_ek6);
		rectangle_ek23 = (View) findViewById(R.id.rectangle_ek23);
		symbol_ek7 = (TextView) findViewById(R.id.symbol_ek7);
		rectangle_ek24 = (View) findViewById(R.id.rectangle_ek24);
		symbol_ek8 = (TextView) findViewById(R.id.symbol_ek8);
		rectangle_ek25 = (View) findViewById(R.id.rectangle_ek25);
		symbol_ek9 = (TextView) findViewById(R.id.symbol_ek9);
		rectangle_ek26 = (View) findViewById(R.id.rectangle_ek26);
		symbol_ek10 = (TextView) findViewById(R.id.symbol_ek10);
		rectangle_ek27 = (View) findViewById(R.id.rectangle_ek27);
		symbol_ek11 = (TextView) findViewById(R.id.symbol_ek11);
		rectangle_ek28 = (View) findViewById(R.id.rectangle_ek28);
		symbol_ek12 = (TextView) findViewById(R.id.symbol_ek12);
		rectangle_ek29 = (View) findViewById(R.id.rectangle_ek29);
		symbol_ek13 = (TextView) findViewById(R.id.symbol_ek13);
		rectangle_ek30 = (View) findViewById(R.id.rectangle_ek30);
		symbol_ek14 = (TextView) findViewById(R.id.symbol_ek14);
		rectangle_ek31 = (View) findViewById(R.id.rectangle_ek31);
		symbol_ek15 = (TextView) findViewById(R.id.symbol_ek15);
		rectangle_ek32 = (View) findViewById(R.id.rectangle_ek32);
		symbol_ek16 = (TextView) findViewById(R.id.symbol_ek16);
		rectangle_ek33 = (View) findViewById(R.id.rectangle_ek33);
		symbol_ek17 = (TextView) findViewById(R.id.symbol_ek17);
		rectangle_ek34 = (View) findViewById(R.id.rectangle_ek34);
		symbol_ek18 = (TextView) findViewById(R.id.symbol_ek18);
		rectangle_ek35 = (View) findViewById(R.id.rectangle_ek35);
		symbol_ek19 = (TextView) findViewById(R.id.symbol_ek19);
		rectangle_ek36 = (View) findViewById(R.id.rectangle_ek36);
		symbol_ek20 = (TextView) findViewById(R.id.symbol_ek20);
		rectangle_ek37 = (View) findViewById(R.id.rectangle_ek37);
		symbol_ek21 = (TextView) findViewById(R.id.symbol_ek21);
		rectangle_ek38 = (View) findViewById(R.id.rectangle_ek38);
		symbol_ek22 = (TextView) findViewById(R.id.symbol_ek22);
		rectangle_ek39 = (View) findViewById(R.id.rectangle_ek39);
		symbol_ek23 = (TextView) findViewById(R.id.symbol_ek23);
		rectangle_ek40 = (View) findViewById(R.id.rectangle_ek40);
		symbol_ek24 = (TextView) findViewById(R.id.symbol_ek24);
		rectangle_ek41 = (View) findViewById(R.id.rectangle_ek41);
		symbol_ek25 = (TextView) findViewById(R.id.symbol_ek25);
		rectangle_ek42 = (View) findViewById(R.id.rectangle_ek42);
		symbol_ek26 = (TextView) findViewById(R.id.symbol_ek26);
		rectangle_ek43 = (ImageView) findViewById(R.id.rectangle_ek43);
		combined_shape_ek6 = (ImageView) findViewById(R.id.combined_shape_ek6);
		rectangle_ek44 = (ImageView) findViewById(R.id.rectangle_ek44);
		wifi_ek6 = (ImageView) findViewById(R.id.wifi_ek6);
		mobile_signal_ek6 = (ImageView) findViewById(R.id.mobile_signal_ek6);
		_9_41_ek6 = (TextView) findViewById(R.id._9_41_ek6);
	
		
		__bg__login1_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), login1_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	