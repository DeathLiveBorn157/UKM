
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class bayar1_activity extends Activity {

	
	private View _bg__bayar1_ek2;
	private TextView next_ek1;
	private TextView credit_card_or_debit_ek1;
	private ImageView vector_ek87;
	private ImageView vector_ek88;
	private View rectangle_ek89;
	private TextView paypal_ek1;
	private ImageView vector_ek89;
	private ImageView vector_ek90;
	private ImageView vector_ek91;
	private ImageView vector_ek92;
	private ImageView vector_ek93;
	private View rectangle_ek90;
	private TextView bank_transfer_ek1;
	private ImageView vector_ek94;
	private ImageView vector_ek95;
	private ImageView vector_ek96;
	private ImageView vector_ek97;
	private ImageView vector_ek98;
	private View rectangle_406_ek6;
	private TextView payment_ek5;
	private View line_39_ek7;
	private ImageView vector_ek99;
	private ImageView vector_ek100;
	private ImageView vector_ek101;
	private ImageView vector_ek102;
	private ImageView rectangle_ek91;
	private ImageView combined_shape_ek13;
	private ImageView rectangle_ek92;
	private ImageView wifi_ek13;
	private ImageView mobile_signal_ek13;
	private TextView _9_41_ek13;
	private View home_indicator_ek15;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.bayar1);

		
		_bg__bayar1_ek2 = (View) findViewById(R.id._bg__bayar1_ek2);
		next_ek1 = (TextView) findViewById(R.id.next_ek1);
		credit_card_or_debit_ek1 = (TextView) findViewById(R.id.credit_card_or_debit_ek1);
		vector_ek87 = (ImageView) findViewById(R.id.vector_ek87);
		vector_ek88 = (ImageView) findViewById(R.id.vector_ek88);
		rectangle_ek89 = (View) findViewById(R.id.rectangle_ek89);
		paypal_ek1 = (TextView) findViewById(R.id.paypal_ek1);
		vector_ek89 = (ImageView) findViewById(R.id.vector_ek89);
		vector_ek90 = (ImageView) findViewById(R.id.vector_ek90);
		vector_ek91 = (ImageView) findViewById(R.id.vector_ek91);
		vector_ek92 = (ImageView) findViewById(R.id.vector_ek92);
		vector_ek93 = (ImageView) findViewById(R.id.vector_ek93);
		rectangle_ek90 = (View) findViewById(R.id.rectangle_ek90);
		bank_transfer_ek1 = (TextView) findViewById(R.id.bank_transfer_ek1);
		vector_ek94 = (ImageView) findViewById(R.id.vector_ek94);
		vector_ek95 = (ImageView) findViewById(R.id.vector_ek95);
		vector_ek96 = (ImageView) findViewById(R.id.vector_ek96);
		vector_ek97 = (ImageView) findViewById(R.id.vector_ek97);
		vector_ek98 = (ImageView) findViewById(R.id.vector_ek98);
		rectangle_406_ek6 = (View) findViewById(R.id.rectangle_406_ek6);
		payment_ek5 = (TextView) findViewById(R.id.payment_ek5);
		line_39_ek7 = (View) findViewById(R.id.line_39_ek7);
		vector_ek99 = (ImageView) findViewById(R.id.vector_ek99);
		vector_ek100 = (ImageView) findViewById(R.id.vector_ek100);
		vector_ek101 = (ImageView) findViewById(R.id.vector_ek101);
		vector_ek102 = (ImageView) findViewById(R.id.vector_ek102);
		rectangle_ek91 = (ImageView) findViewById(R.id.rectangle_ek91);
		combined_shape_ek13 = (ImageView) findViewById(R.id.combined_shape_ek13);
		rectangle_ek92 = (ImageView) findViewById(R.id.rectangle_ek92);
		wifi_ek13 = (ImageView) findViewById(R.id.wifi_ek13);
		mobile_signal_ek13 = (ImageView) findViewById(R.id.mobile_signal_ek13);
		_9_41_ek13 = (TextView) findViewById(R.id._9_41_ek13);
		home_indicator_ek15 = (View) findViewById(R.id.home_indicator_ek15);
	
		
		//custom code goes here
	
	}
}
	
	