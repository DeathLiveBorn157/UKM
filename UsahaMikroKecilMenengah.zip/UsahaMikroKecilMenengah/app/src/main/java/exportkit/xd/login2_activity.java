
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class login2_activity extends Activity {

	
	private View __bg__login2_ek2;
	private ImageView image_1_ek4;
	private TextView let_s_get_started;
	private TextView create_an_new_account;
	private ImageView vector__stroke__ek19;
	private ImageView vector__stroke__ek20;
	private TextView full_name;
	private ImageView vector__stroke__ek21;
	private ImageView vector__stroke__ek22;
	private TextView your_email_ek3;
	private ImageView vector__stroke__ek23;
	private ImageView vector__stroke__ek24;
	private ImageView vector__stroke__ek25;
	private TextView password_ek1;
	private ImageView vector__stroke__ek26;
	private ImageView vector__stroke__ek27;
	private ImageView vector__stroke__ek28;
	private TextView password_again;
	private TextView sign_up;
	private TextView have_a_account__sign_in;
	private ImageView rectangle_ek47;
	private ImageView combined_shape_ek8;
	private ImageView rectangle_ek48;
	private ImageView wifi_ek8;
	private ImageView mobile_signal_ek8;
	private TextView _9_41_ek8;
	private View home_indicator_ek9;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login2);

		
		__bg__login2_ek2 = (View) findViewById(R.id.__bg__login2_ek2);
		image_1_ek4 = (ImageView) findViewById(R.id.image_1_ek4);
		let_s_get_started = (TextView) findViewById(R.id.let_s_get_started);
		create_an_new_account = (TextView) findViewById(R.id.create_an_new_account);
		vector__stroke__ek19 = (ImageView) findViewById(R.id.vector__stroke__ek19);
		vector__stroke__ek20 = (ImageView) findViewById(R.id.vector__stroke__ek20);
		full_name = (TextView) findViewById(R.id.full_name);
		vector__stroke__ek21 = (ImageView) findViewById(R.id.vector__stroke__ek21);
		vector__stroke__ek22 = (ImageView) findViewById(R.id.vector__stroke__ek22);
		your_email_ek3 = (TextView) findViewById(R.id.your_email_ek3);
		vector__stroke__ek23 = (ImageView) findViewById(R.id.vector__stroke__ek23);
		vector__stroke__ek24 = (ImageView) findViewById(R.id.vector__stroke__ek24);
		vector__stroke__ek25 = (ImageView) findViewById(R.id.vector__stroke__ek25);
		password_ek1 = (TextView) findViewById(R.id.password_ek1);
		vector__stroke__ek26 = (ImageView) findViewById(R.id.vector__stroke__ek26);
		vector__stroke__ek27 = (ImageView) findViewById(R.id.vector__stroke__ek27);
		vector__stroke__ek28 = (ImageView) findViewById(R.id.vector__stroke__ek28);
		password_again = (TextView) findViewById(R.id.password_again);
		sign_up = (TextView) findViewById(R.id.sign_up);
		have_a_account__sign_in = (TextView) findViewById(R.id.have_a_account__sign_in);
		rectangle_ek47 = (ImageView) findViewById(R.id.rectangle_ek47);
		combined_shape_ek8 = (ImageView) findViewById(R.id.combined_shape_ek8);
		rectangle_ek48 = (ImageView) findViewById(R.id.rectangle_ek48);
		wifi_ek8 = (ImageView) findViewById(R.id.wifi_ek8);
		mobile_signal_ek8 = (ImageView) findViewById(R.id.mobile_signal_ek8);
		_9_41_ek8 = (TextView) findViewById(R.id._9_41_ek8);
		home_indicator_ek9 = (View) findViewById(R.id.home_indicator_ek9);
	
		
		__bg__login2_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), login3_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	