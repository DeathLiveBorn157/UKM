
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

public class login3_activity extends Activity {

	
	private View __bg__login3_ek2;
	private ImageView image_1_ek5;
	private ImageView vector__stroke__ek29;
	private ImageView vector__stroke__ek30;
	private TextView full_name_ek1;
	private ImageView vector__stroke__ek31;
	private ImageView vector__stroke__ek32;
	private TextView your_email_ek4;
	private ImageView vector__stroke__ek33;
	private ImageView vector__stroke__ek34;
	private ImageView vector__stroke__ek35;
	private TextView password_ek2;
	private ImageView vector__stroke__ek36;
	private ImageView vector__stroke__ek37;
	private ImageView vector__stroke__ek38;
	private TextView password_again_ek1;
	private TextView sign_up_ek1;
	private TextView have_a_account__sign_in_ek1;
	private TextView let_s_get_started_ek1;
	private TextView create_an_new_account_ek1;
	private ImageView rectangle_ek49;
	private ImageView combined_shape_ek9;
	private ImageView rectangle_ek50;
	private ImageView wifi_ek9;
	private ImageView mobile_signal_ek9;
	private TextView _9_41_ek9;
	private View background_ek3;
	private View home_indicator_ek11;
	private ImageView dictation_ek1;
	private ImageView emoji_ek1;
	private ImageView rectangle_ek51;
	private TextView label_ek4;
	private ImageView rectangle_ek52;
	private TextView label_ek5;
	private ImageView rectangle_ek53;
	private TextView label_ek6;
	private ImageView rectangle_ek54;
	private TextView label_ek7;
	private ImageView delete_button_ek1;
	private View rectangle_ek55;
	private TextView symbol_ek27;
	private ImageView shift_ek3;
	private View rectangle_ek56;
	private TextView symbol_ek28;
	private View rectangle_ek57;
	private TextView symbol_ek29;
	private View rectangle_ek58;
	private TextView symbol_ek30;
	private View rectangle_ek59;
	private TextView symbol_ek31;
	private View rectangle_ek60;
	private TextView symbol_ek32;
	private View rectangle_ek61;
	private TextView symbol_ek33;
	private View rectangle_ek62;
	private TextView symbol_ek34;
	private View rectangle_ek63;
	private TextView symbol_ek35;
	private View rectangle_ek64;
	private TextView symbol_ek36;
	private View rectangle_ek65;
	private TextView symbol_ek37;
	private View rectangle_ek66;
	private TextView symbol_ek38;
	private View rectangle_ek67;
	private TextView symbol_ek39;
	private View rectangle_ek68;
	private TextView symbol_ek40;
	private View rectangle_ek69;
	private TextView symbol_ek41;
	private View rectangle_ek70;
	private TextView symbol_ek42;
	private View rectangle_ek71;
	private TextView symbol_ek43;
	private View rectangle_ek72;
	private TextView symbol_ek44;
	private View rectangle_ek73;
	private TextView symbol_ek45;
	private View rectangle_ek74;
	private TextView symbol_ek46;
	private View rectangle_ek75;
	private TextView symbol_ek47;
	private View rectangle_ek76;
	private TextView symbol_ek48;
	private View rectangle_ek77;
	private TextView symbol_ek49;
	private View rectangle_ek78;
	private TextView symbol_ek50;
	private View rectangle_ek79;
	private TextView symbol_ek51;
	private View rectangle_ek80;
	private TextView symbol_ek52;
	private View rectangle_ek81;
	private TextView symbol_ek53;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login3);

		
		__bg__login3_ek2 = (View) findViewById(R.id.__bg__login3_ek2);
		image_1_ek5 = (ImageView) findViewById(R.id.image_1_ek5);
		vector__stroke__ek29 = (ImageView) findViewById(R.id.vector__stroke__ek29);
		vector__stroke__ek30 = (ImageView) findViewById(R.id.vector__stroke__ek30);
		full_name_ek1 = (TextView) findViewById(R.id.full_name_ek1);
		vector__stroke__ek31 = (ImageView) findViewById(R.id.vector__stroke__ek31);
		vector__stroke__ek32 = (ImageView) findViewById(R.id.vector__stroke__ek32);
		your_email_ek4 = (TextView) findViewById(R.id.your_email_ek4);
		vector__stroke__ek33 = (ImageView) findViewById(R.id.vector__stroke__ek33);
		vector__stroke__ek34 = (ImageView) findViewById(R.id.vector__stroke__ek34);
		vector__stroke__ek35 = (ImageView) findViewById(R.id.vector__stroke__ek35);
		password_ek2 = (TextView) findViewById(R.id.password_ek2);
		vector__stroke__ek36 = (ImageView) findViewById(R.id.vector__stroke__ek36);
		vector__stroke__ek37 = (ImageView) findViewById(R.id.vector__stroke__ek37);
		vector__stroke__ek38 = (ImageView) findViewById(R.id.vector__stroke__ek38);
		password_again_ek1 = (TextView) findViewById(R.id.password_again_ek1);
		sign_up_ek1 = (TextView) findViewById(R.id.sign_up_ek1);
		have_a_account__sign_in_ek1 = (TextView) findViewById(R.id.have_a_account__sign_in_ek1);
		let_s_get_started_ek1 = (TextView) findViewById(R.id.let_s_get_started_ek1);
		create_an_new_account_ek1 = (TextView) findViewById(R.id.create_an_new_account_ek1);
		rectangle_ek49 = (ImageView) findViewById(R.id.rectangle_ek49);
		combined_shape_ek9 = (ImageView) findViewById(R.id.combined_shape_ek9);
		rectangle_ek50 = (ImageView) findViewById(R.id.rectangle_ek50);
		wifi_ek9 = (ImageView) findViewById(R.id.wifi_ek9);
		mobile_signal_ek9 = (ImageView) findViewById(R.id.mobile_signal_ek9);
		_9_41_ek9 = (TextView) findViewById(R.id._9_41_ek9);
		background_ek3 = (View) findViewById(R.id.background_ek3);
		home_indicator_ek11 = (View) findViewById(R.id.home_indicator_ek11);
		dictation_ek1 = (ImageView) findViewById(R.id.dictation_ek1);
		emoji_ek1 = (ImageView) findViewById(R.id.emoji_ek1);
		rectangle_ek51 = (ImageView) findViewById(R.id.rectangle_ek51);
		label_ek4 = (TextView) findViewById(R.id.label_ek4);
		rectangle_ek52 = (ImageView) findViewById(R.id.rectangle_ek52);
		label_ek5 = (TextView) findViewById(R.id.label_ek5);
		rectangle_ek53 = (ImageView) findViewById(R.id.rectangle_ek53);
		label_ek6 = (TextView) findViewById(R.id.label_ek6);
		rectangle_ek54 = (ImageView) findViewById(R.id.rectangle_ek54);
		label_ek7 = (TextView) findViewById(R.id.label_ek7);
		delete_button_ek1 = (ImageView) findViewById(R.id.delete_button_ek1);
		rectangle_ek55 = (View) findViewById(R.id.rectangle_ek55);
		symbol_ek27 = (TextView) findViewById(R.id.symbol_ek27);
		shift_ek3 = (ImageView) findViewById(R.id.shift_ek3);
		rectangle_ek56 = (View) findViewById(R.id.rectangle_ek56);
		symbol_ek28 = (TextView) findViewById(R.id.symbol_ek28);
		rectangle_ek57 = (View) findViewById(R.id.rectangle_ek57);
		symbol_ek29 = (TextView) findViewById(R.id.symbol_ek29);
		rectangle_ek58 = (View) findViewById(R.id.rectangle_ek58);
		symbol_ek30 = (TextView) findViewById(R.id.symbol_ek30);
		rectangle_ek59 = (View) findViewById(R.id.rectangle_ek59);
		symbol_ek31 = (TextView) findViewById(R.id.symbol_ek31);
		rectangle_ek60 = (View) findViewById(R.id.rectangle_ek60);
		symbol_ek32 = (TextView) findViewById(R.id.symbol_ek32);
		rectangle_ek61 = (View) findViewById(R.id.rectangle_ek61);
		symbol_ek33 = (TextView) findViewById(R.id.symbol_ek33);
		rectangle_ek62 = (View) findViewById(R.id.rectangle_ek62);
		symbol_ek34 = (TextView) findViewById(R.id.symbol_ek34);
		rectangle_ek63 = (View) findViewById(R.id.rectangle_ek63);
		symbol_ek35 = (TextView) findViewById(R.id.symbol_ek35);
		rectangle_ek64 = (View) findViewById(R.id.rectangle_ek64);
		symbol_ek36 = (TextView) findViewById(R.id.symbol_ek36);
		rectangle_ek65 = (View) findViewById(R.id.rectangle_ek65);
		symbol_ek37 = (TextView) findViewById(R.id.symbol_ek37);
		rectangle_ek66 = (View) findViewById(R.id.rectangle_ek66);
		symbol_ek38 = (TextView) findViewById(R.id.symbol_ek38);
		rectangle_ek67 = (View) findViewById(R.id.rectangle_ek67);
		symbol_ek39 = (TextView) findViewById(R.id.symbol_ek39);
		rectangle_ek68 = (View) findViewById(R.id.rectangle_ek68);
		symbol_ek40 = (TextView) findViewById(R.id.symbol_ek40);
		rectangle_ek69 = (View) findViewById(R.id.rectangle_ek69);
		symbol_ek41 = (TextView) findViewById(R.id.symbol_ek41);
		rectangle_ek70 = (View) findViewById(R.id.rectangle_ek70);
		symbol_ek42 = (TextView) findViewById(R.id.symbol_ek42);
		rectangle_ek71 = (View) findViewById(R.id.rectangle_ek71);
		symbol_ek43 = (TextView) findViewById(R.id.symbol_ek43);
		rectangle_ek72 = (View) findViewById(R.id.rectangle_ek72);
		symbol_ek44 = (TextView) findViewById(R.id.symbol_ek44);
		rectangle_ek73 = (View) findViewById(R.id.rectangle_ek73);
		symbol_ek45 = (TextView) findViewById(R.id.symbol_ek45);
		rectangle_ek74 = (View) findViewById(R.id.rectangle_ek74);
		symbol_ek46 = (TextView) findViewById(R.id.symbol_ek46);
		rectangle_ek75 = (View) findViewById(R.id.rectangle_ek75);
		symbol_ek47 = (TextView) findViewById(R.id.symbol_ek47);
		rectangle_ek76 = (View) findViewById(R.id.rectangle_ek76);
		symbol_ek48 = (TextView) findViewById(R.id.symbol_ek48);
		rectangle_ek77 = (View) findViewById(R.id.rectangle_ek77);
		symbol_ek49 = (TextView) findViewById(R.id.symbol_ek49);
		rectangle_ek78 = (View) findViewById(R.id.rectangle_ek78);
		symbol_ek50 = (TextView) findViewById(R.id.symbol_ek50);
		rectangle_ek79 = (View) findViewById(R.id.rectangle_ek79);
		symbol_ek51 = (TextView) findViewById(R.id.symbol_ek51);
		rectangle_ek80 = (View) findViewById(R.id.rectangle_ek80);
		symbol_ek52 = (TextView) findViewById(R.id.symbol_ek52);
		rectangle_ek81 = (View) findViewById(R.id.rectangle_ek81);
		symbol_ek53 = (TextView) findViewById(R.id.symbol_ek53);
	
		
		__bg__login3_ek2.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), login3_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	