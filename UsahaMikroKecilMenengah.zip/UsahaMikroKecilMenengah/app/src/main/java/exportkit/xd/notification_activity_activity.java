
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class notification_activity_activity extends Activity {

	
	private View _bg__notification_activity_ek2;
	private TextView offer_ek2;
	private ImageView vector_ek30;
	private ImageView vector_ek31;
	private ImageView vector_ek32;
	private ImageView vector_ek33;
	private TextView transaction_nike_air_zoom_product;
	private TextView culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek2;
	private TextView april_30__2014_1_01_pm_ek3;
	private ImageView vector_ek34;
	private ImageView vector_ek35;
	private ImageView vector_ek36;
	private ImageView vector_ek37;
	private TextView transaction_nike_air_zoom_pegasus_36_miami;
	private TextView culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_ek1;
	private TextView april_30__2014_1_01_pm_ek4;
	private View rectangle_406_ek3;
	private TextView payment_ek4;
	private View line_39_ek3;
	private ImageView vector_ek38;
	private ImageView vector_ek39;
	private ImageView vector_ek40;
	private ImageView vector_ek41;
	private ImageView rectangle_ek8;
	private ImageView combined_shape_ek4;
	private ImageView rectangle_ek9;
	private ImageView wifi_ek4;
	private ImageView mobile_signal_ek4;
	private TextView _9_41_ek4;
	private View home_indicator_ek4;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.notification_activity);

		
		_bg__notification_activity_ek2 = (View) findViewById(R.id._bg__notification_activity_ek2);
		offer_ek2 = (TextView) findViewById(R.id.offer_ek2);
		vector_ek30 = (ImageView) findViewById(R.id.vector_ek30);
		vector_ek31 = (ImageView) findViewById(R.id.vector_ek31);
		vector_ek32 = (ImageView) findViewById(R.id.vector_ek32);
		vector_ek33 = (ImageView) findViewById(R.id.vector_ek33);
		transaction_nike_air_zoom_product = (TextView) findViewById(R.id.transaction_nike_air_zoom_product);
		culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek2 = (TextView) findViewById(R.id.culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_amet_deserunt_ex_proident_commodo_ek2);
		april_30__2014_1_01_pm_ek3 = (TextView) findViewById(R.id.april_30__2014_1_01_pm_ek3);
		vector_ek34 = (ImageView) findViewById(R.id.vector_ek34);
		vector_ek35 = (ImageView) findViewById(R.id.vector_ek35);
		vector_ek36 = (ImageView) findViewById(R.id.vector_ek36);
		vector_ek37 = (ImageView) findViewById(R.id.vector_ek37);
		transaction_nike_air_zoom_pegasus_36_miami = (TextView) findViewById(R.id.transaction_nike_air_zoom_pegasus_36_miami);
		culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_ek1 = (TextView) findViewById(R.id.culpa_cillum_consectetur_labore_nulla_nulla_magna_irure__id_veniam_culpa_officia_aute_dolor_ek1);
		april_30__2014_1_01_pm_ek4 = (TextView) findViewById(R.id.april_30__2014_1_01_pm_ek4);
		rectangle_406_ek3 = (View) findViewById(R.id.rectangle_406_ek3);
		payment_ek4 = (TextView) findViewById(R.id.payment_ek4);
		line_39_ek3 = (View) findViewById(R.id.line_39_ek3);
		vector_ek38 = (ImageView) findViewById(R.id.vector_ek38);
		vector_ek39 = (ImageView) findViewById(R.id.vector_ek39);
		vector_ek40 = (ImageView) findViewById(R.id.vector_ek40);
		vector_ek41 = (ImageView) findViewById(R.id.vector_ek41);
		rectangle_ek8 = (ImageView) findViewById(R.id.rectangle_ek8);
		combined_shape_ek4 = (ImageView) findViewById(R.id.combined_shape_ek4);
		rectangle_ek9 = (ImageView) findViewById(R.id.rectangle_ek9);
		wifi_ek4 = (ImageView) findViewById(R.id.wifi_ek4);
		mobile_signal_ek4 = (ImageView) findViewById(R.id.mobile_signal_ek4);
		_9_41_ek4 = (TextView) findViewById(R.id._9_41_ek4);
		home_indicator_ek4 = (View) findViewById(R.id.home_indicator_ek4);
	
		
		//custom code goes here
	
	}
}
	
	