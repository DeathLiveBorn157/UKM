
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class wishlist_activity extends Activity {

	
	private View _bg__wishlist_ek2;
	private View line_41;
	private View line_42;
	private ImageView image_product;
	private TextView nike_air_max_270_react_eng;
	private ImageView s01tar;
	private ImageView s02tar;
	private ImageView s03tar;
	private ImageView s04tar;
	private ImageView s05tar;
	private TextView __299_43_ek3;
	private TextView __534_33_ek3;
	private TextView _24__off_ek3;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private ImageView image_product_ek1;
	private TextView nike_air_max_270_react_eng_ek1;
	private ImageView s01tar_ek1;
	private ImageView s02tar_ek1;
	private ImageView s03tar_ek1;
	private ImageView s04tar_ek1;
	private ImageView s05tar_ek1;
	private TextView __299_43_ek4;
	private TextView __534_33_ek4;
	private TextView _24__off_ek4;
	private ImageView vector_ek4;
	private ImageView vector_ek5;
	private ImageView image_product_ek2;
	private TextView nike_air_max_270_react_eng_ek2;
	private ImageView s01tar_ek2;
	private ImageView s02tar_ek2;
	private ImageView s03tar_ek2;
	private ImageView s04tar_ek2;
	private ImageView s05tar_ek2;
	private TextView __299_43_ek5;
	private TextView __534_33_ek5;
	private TextView _24__off_ek5;
	private ImageView image_product_ek3;
	private TextView nike_air_max_270_react_eng_ek3;
	private ImageView s01tar_ek3;
	private ImageView s02tar_ek3;
	private ImageView s03tar_ek3;
	private ImageView s04tar_ek3;
	private ImageView s05tar_ek3;
	private TextView __299_43_ek6;
	private TextView __534_33_ek6;
	private TextView _24__off_ek6;
	private ImageView vector_ek6;
	private ImageView vector_ek7;
	private ImageView vector_ek8;
	private ImageView vector_ek9;
	private View rectangle_406;
	private TextView payment;
	private View line_39;
	private ImageView vector_ek10;
	private ImageView vector_ek11;
	private ImageView vector_ek12;
	private ImageView vector_ek13;
	private ImageView rectangle_ek2;
	private ImageView combined_shape_ek1;
	private ImageView rectangle_ek3;
	private ImageView wifi_ek1;
	private ImageView mobile_signal_ek1;
	private TextView _9_41_ek1;
	private View home_indicator_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.wishlist);

		
		_bg__wishlist_ek2 = (View) findViewById(R.id._bg__wishlist_ek2);
		line_41 = (View) findViewById(R.id.line_41);
		line_42 = (View) findViewById(R.id.line_42);
		image_product = (ImageView) findViewById(R.id.image_product);
		nike_air_max_270_react_eng = (TextView) findViewById(R.id.nike_air_max_270_react_eng);
		s01tar = (ImageView) findViewById(R.id.s01tar);
		s02tar = (ImageView) findViewById(R.id.s02tar);
		s03tar = (ImageView) findViewById(R.id.s03tar);
		s04tar = (ImageView) findViewById(R.id.s04tar);
		s05tar = (ImageView) findViewById(R.id.s05tar);
		__299_43_ek3 = (TextView) findViewById(R.id.__299_43_ek3);
		__534_33_ek3 = (TextView) findViewById(R.id.__534_33_ek3);
		_24__off_ek3 = (TextView) findViewById(R.id._24__off_ek3);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		image_product_ek1 = (ImageView) findViewById(R.id.image_product_ek1);
		nike_air_max_270_react_eng_ek1 = (TextView) findViewById(R.id.nike_air_max_270_react_eng_ek1);
		s01tar_ek1 = (ImageView) findViewById(R.id.s01tar_ek1);
		s02tar_ek1 = (ImageView) findViewById(R.id.s02tar_ek1);
		s03tar_ek1 = (ImageView) findViewById(R.id.s03tar_ek1);
		s04tar_ek1 = (ImageView) findViewById(R.id.s04tar_ek1);
		s05tar_ek1 = (ImageView) findViewById(R.id.s05tar_ek1);
		__299_43_ek4 = (TextView) findViewById(R.id.__299_43_ek4);
		__534_33_ek4 = (TextView) findViewById(R.id.__534_33_ek4);
		_24__off_ek4 = (TextView) findViewById(R.id._24__off_ek4);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		vector_ek5 = (ImageView) findViewById(R.id.vector_ek5);
		image_product_ek2 = (ImageView) findViewById(R.id.image_product_ek2);
		nike_air_max_270_react_eng_ek2 = (TextView) findViewById(R.id.nike_air_max_270_react_eng_ek2);
		s01tar_ek2 = (ImageView) findViewById(R.id.s01tar_ek2);
		s02tar_ek2 = (ImageView) findViewById(R.id.s02tar_ek2);
		s03tar_ek2 = (ImageView) findViewById(R.id.s03tar_ek2);
		s04tar_ek2 = (ImageView) findViewById(R.id.s04tar_ek2);
		s05tar_ek2 = (ImageView) findViewById(R.id.s05tar_ek2);
		__299_43_ek5 = (TextView) findViewById(R.id.__299_43_ek5);
		__534_33_ek5 = (TextView) findViewById(R.id.__534_33_ek5);
		_24__off_ek5 = (TextView) findViewById(R.id._24__off_ek5);
		image_product_ek3 = (ImageView) findViewById(R.id.image_product_ek3);
		nike_air_max_270_react_eng_ek3 = (TextView) findViewById(R.id.nike_air_max_270_react_eng_ek3);
		s01tar_ek3 = (ImageView) findViewById(R.id.s01tar_ek3);
		s02tar_ek3 = (ImageView) findViewById(R.id.s02tar_ek3);
		s03tar_ek3 = (ImageView) findViewById(R.id.s03tar_ek3);
		s04tar_ek3 = (ImageView) findViewById(R.id.s04tar_ek3);
		s05tar_ek3 = (ImageView) findViewById(R.id.s05tar_ek3);
		__299_43_ek6 = (TextView) findViewById(R.id.__299_43_ek6);
		__534_33_ek6 = (TextView) findViewById(R.id.__534_33_ek6);
		_24__off_ek6 = (TextView) findViewById(R.id._24__off_ek6);
		vector_ek6 = (ImageView) findViewById(R.id.vector_ek6);
		vector_ek7 = (ImageView) findViewById(R.id.vector_ek7);
		vector_ek8 = (ImageView) findViewById(R.id.vector_ek8);
		vector_ek9 = (ImageView) findViewById(R.id.vector_ek9);
		rectangle_406 = (View) findViewById(R.id.rectangle_406);
		payment = (TextView) findViewById(R.id.payment);
		line_39 = (View) findViewById(R.id.line_39);
		vector_ek10 = (ImageView) findViewById(R.id.vector_ek10);
		vector_ek11 = (ImageView) findViewById(R.id.vector_ek11);
		vector_ek12 = (ImageView) findViewById(R.id.vector_ek12);
		vector_ek13 = (ImageView) findViewById(R.id.vector_ek13);
		rectangle_ek2 = (ImageView) findViewById(R.id.rectangle_ek2);
		combined_shape_ek1 = (ImageView) findViewById(R.id.combined_shape_ek1);
		rectangle_ek3 = (ImageView) findViewById(R.id.rectangle_ek3);
		wifi_ek1 = (ImageView) findViewById(R.id.wifi_ek1);
		mobile_signal_ek1 = (ImageView) findViewById(R.id.mobile_signal_ek1);
		_9_41_ek1 = (TextView) findViewById(R.id._9_41_ek1);
		home_indicator_ek1 = (View) findViewById(R.id.home_indicator_ek1);
	
		
		//custom code goes here
	
	}
}
	
	