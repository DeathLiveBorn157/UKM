
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		menu
	 *	@date 		1655824687425
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class bayar2_activity extends Activity {

	
	private View _bg__bayar2_ek2;
	private TextView pay__766_86;
	private ImageView image_49;
	private ImageView image_50;
	private View line_41_ek1;
	private View line_42_ek1;
	private TextView gopay;
	private TextView ovo;
	private TextView saldo___rp225_000;
	private TextView saldo___rp20_000;
	private View ellipse_115;
	private View ellipse_114;
	private View ellipse_115_ek1;
	private View rectangle_406_ek7;
	private TextView payment_ek6;
	private View line_39_ek8;
	private ImageView vector_ek103;
	private ImageView vector_ek104;
	private ImageView vector_ek105;
	private ImageView vector_ek106;
	private ImageView rectangle_ek93;
	private ImageView combined_shape_ek14;
	private ImageView rectangle_ek94;
	private ImageView wifi_ek14;
	private ImageView mobile_signal_ek14;
	private TextView _9_41_ek14;
	private View home_indicator_ek16;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.bayar2);

		
		_bg__bayar2_ek2 = (View) findViewById(R.id._bg__bayar2_ek2);
		pay__766_86 = (TextView) findViewById(R.id.pay__766_86);
		image_49 = (ImageView) findViewById(R.id.image_49);
		image_50 = (ImageView) findViewById(R.id.image_50);
		line_41_ek1 = (View) findViewById(R.id.line_41_ek1);
		line_42_ek1 = (View) findViewById(R.id.line_42_ek1);
		gopay = (TextView) findViewById(R.id.gopay);
		ovo = (TextView) findViewById(R.id.ovo);
		saldo___rp225_000 = (TextView) findViewById(R.id.saldo___rp225_000);
		saldo___rp20_000 = (TextView) findViewById(R.id.saldo___rp20_000);
		ellipse_115 = (View) findViewById(R.id.ellipse_115);
		ellipse_114 = (View) findViewById(R.id.ellipse_114);
		ellipse_115_ek1 = (View) findViewById(R.id.ellipse_115_ek1);
		rectangle_406_ek7 = (View) findViewById(R.id.rectangle_406_ek7);
		payment_ek6 = (TextView) findViewById(R.id.payment_ek6);
		line_39_ek8 = (View) findViewById(R.id.line_39_ek8);
		vector_ek103 = (ImageView) findViewById(R.id.vector_ek103);
		vector_ek104 = (ImageView) findViewById(R.id.vector_ek104);
		vector_ek105 = (ImageView) findViewById(R.id.vector_ek105);
		vector_ek106 = (ImageView) findViewById(R.id.vector_ek106);
		rectangle_ek93 = (ImageView) findViewById(R.id.rectangle_ek93);
		combined_shape_ek14 = (ImageView) findViewById(R.id.combined_shape_ek14);
		rectangle_ek94 = (ImageView) findViewById(R.id.rectangle_ek94);
		wifi_ek14 = (ImageView) findViewById(R.id.wifi_ek14);
		mobile_signal_ek14 = (ImageView) findViewById(R.id.mobile_signal_ek14);
		_9_41_ek14 = (TextView) findViewById(R.id._9_41_ek14);
		home_indicator_ek16 = (View) findViewById(R.id.home_indicator_ek16);
	
		
		//custom code goes here
	
	}
}
	
	